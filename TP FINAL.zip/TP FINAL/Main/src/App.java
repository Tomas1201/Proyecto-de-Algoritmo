import java.io.File;
import java.util.Scanner;
import java.util.Stack;

//Crear mensajes por consola para cada metodo especifico, demostrando su funcion
public class App {

    public static boolean disponible, reservado;
    public static int eleccion;
    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) throws Exception {
        Presentar();

    }

    public static void Presentar() {
        // Presentacion del programa
        System.out.println("");
        eleccion = sc.nextInt();

        switch (eleccion) {
            // 1 para ver el catalogo
            case 1:
                VerCatalogo();
                // 2 para agregar libro
            case 2:
                AgregarLibro();
                // 0 para salir
            case 0:
                break;

        }

    }

    public static void AgregarLibro() {
        // La opcion del switch
        Agregar();

    }

    public static void Agregar() {
        // Pedirle al usuario los datos del libro para creaer el archivo tipo file

    }

    public static void SacarLibro() {
        // Opcion de BuscarNombre

    }

    public static void VerCatalogo() {
        // Opcion del switch
        // Posiblemente de error por haber utilizado la misma variable en el switch
        // anterior y no ser limpiado, en caso de milagro, no se toca gente
        eleccion = sc.nextInt();

        switch (eleccion) {
            // 1 para ver todos los archivos
            case 1:
                Todo();
                // 2 para filtrar los generos de los libros
            case 2:
                Temario();
                // 3 para filtrar los libros por los que tengan el estado "disponible" en true
                // TERMINAR
            case 3:

        }

    }

    public static void Temario() {
        // Va a contener los temas de los libros (Una clase general)
        eleccion = sc.nextInt();

        switch (eleccion) {
            // 1 para Informatica
            case 1:
                VerInformatica();
                // 2 para ver Finanzas
            case 2:
                VerFinanzas();
                // 3 para ver Idiomas
            case 3:
                VerIdiomas();
                // 4 para ver Historia
            case 4:
                VerHistorias();
                // 5 para ver Otros
            case 5:
                VerOtros();

        }

    }

    public static void Todo() {
        // La llamada al array que contenga todos los libros
    }

    public static void FiltrarNombre() {
        // Se va a utilizar para encontar un libro en especifico y va a devolver sus
        // datos

    }

    public static void LeerLibro() {
        // Opcion de BuscarNombre

    }

    public static boolean Disponible() {
        // Retorna el estado del libro para utilizarse en
        Libros libros = new Libros();
        return libros.disponible;
    }

    public static Stack<File> FiltrarLibro(){
        //Retorna el stack de los libros disponibles filtrados por la funcion "Disponible"
        return 
    }

    public static void VerInformatica() {
        // Para ver el conjunto "Informatica"

    }

    public static void VerFinanzas() {
        // Para ver el conjunto "Finanzas"
    }

    public static void VerIdiomas() {
        // Para ver el conjunto "Idiomas"
    }

    public static void VerHistorias() {
        // Para ver el conjunto "Historias"
    }

    public static void VerOtros() {
        // Para ver el conjunto "Otros"
    }
}

// Valen dijo que esta quedando facherito 18:35Hs El dolar llego a $1020 de
// venta, ivo se quiere cortar los huevos
