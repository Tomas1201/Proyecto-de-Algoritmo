//Va a contener los arrays y pilas con los temas de los libros

import java.io.File;
import java.util.Stack;

public class Temas {
    File[] informatica, historias;
    Stack<File> idiomas = new Stack<File>();
    Stack<File> finanzas = new Stack<File>();
    Stack<File> todo = new Stack<File>();
    Stack<File> otros = new Stack<File>();

}
