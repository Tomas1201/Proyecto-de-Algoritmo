import java.util.Scanner;

//Esta clase va a contener las caracteristicas y los libros
public class Libros {

    public static boolean disponible;
    public static boolean reservado;
    Scanner sc = new Scanner(System.in);
    // Va a contener variable tipo file llamadas "nombre",
    String autor, sinopsis;

}
