package com.example;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Archvos {
	static String NombreTematica;
	static Scanner sc = new Scanner(System.in);
	static File Raiz = new File("C:\\Pepe\\");
	public static boolean estado;

	public static void CrearLibro(String NombreLibro, String Autor, String descipcion) throws IOException {
		FileWriter Libro = null;
		try {
			Libro = new FileWriter("C:\\Pepe\\Tematicas\\Otros\\" + NombreLibro + ".json");

			Libro.write("{" + "\"hecho por\"" + ": " + "\"" + Autor + "\"" + "," + "\n" + "\"Epilogo\"" + ":" + "\""
					+ descipcion + "\"" + "}");

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			Libro.close();
		}
		System.out.println("Se a guardado el libro con exito");

	}

	public static void MostrarArchivos(File Ruta) {

		for (File ArchDire : Ruta.listFiles()) {

			if (ArchDire.isFile()) {

				SacarTXT(ArchDire.getName());
			}

			else if (ArchDire.isDirectory()) {
				System.out.println(ArchDire.getName() + ": ");
				MostrarArchivos(ArchDire);
			}
		}
	}

	public static void SacarTXT(String Nombre) {
		int Longitud = Nombre.length();
		String Renombre = Nombre.substring(0, Longitud - 4);
		System.out.println("* " + Renombre);

	}

}
