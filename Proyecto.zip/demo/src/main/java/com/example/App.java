package com.example;

import org.json.simple.parser.JSONParser;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Scanner;

public class App {

    public static boolean disponible;
    public static int eleccion;
    public static String eleccionArchivo, RutaGeneral, nombreArchivo, nombreLibro, autorLibro, descripcionLibro;
    public static Scanner sc = new Scanner(System.in);
    public static Archvos biblioteca = new Archvos();
    static File Raiz = new File("C:\\Pepe\\");
    static File Tematicas = new File("C:\\Pepe\\Tematicas\\");
    static File desarrolloPersonal = new File("C:\\Pepe\\Tematicas\\Desarollo personal\\");
    public static File historias = new File("C:\\Pepe\\Tematicas\\Historias\\");
    public static File matematicas = new File("C:\\Pepe\\Tematicas\\Matematicas\\");
    public static File misticos = new File("C:\\Pepe\\Tematicas\\Misticos\\");
    public static File otros = new File("C:\\Pepe\\Tematicas\\Otros\\");
    public static File reservado = new File("C:\\Pepe\\Reservado");
    public static Scanner eleccionAr = new Scanner(System.in);
    public static Scanner eleccionLeer = new Scanner(System.in);

    public static void main(String[] args) throws Exception {

        Presentar();

        switch (eleccion) {

            case 1:
                VerCatalogo();
                break;

            case 2:
                AgregarLibro();

            case 0:
                break;

        }

    }

    public static void Presentar() {

        System.out.println("\r\n" + //
                "  ____  _                               _ _                 _ _ _____         _____  ______ _ _ \r\n" + //
                " |  _ \\(_)                             | (_)               ( | / ____|  /\\   |  __ \\|  ____( | )\r\n"
                + //
                " | |_) |_  ___ _ ____   _____ _ __   __| |_  ___     __ _   V | (___   /  \\  | |__) | |__   V V \r\n"
                + //
                " |  _ <| |/ _ | '_ \\ \\ / / _ | '_ \\ / _` | |/ _ \\   / _` |     \\___ \\ / /\\ \\ |  ___/|  __|      \r\n"
                + //
                " | |_) | |  __| | | \\ V |  __| | | | (_| | | (_) | | (_| |     ____) / ____ \\| |    | |____     \r\n"
                + //
                " |____/|_|\\___|_| |_|\\_/ \\___|_| |_|\\__,_|_|\\___/   \\__,_|    |_____/_/    \\_|_|    |______|    \r\n"
                + //
                "                                                                                                \r\n" + //
                "                                                                                                \r\n" + //
                " \n " +
                "\r\n" + //
                "   _____       __                               \r\n" + //
                "  / ___/____ _/ /_  ___  _____                  \r\n" + //
                "  \\__ \\/ __ `/ __ \\/ _ \\/ ___/                  \r\n" + //
                " ___/ / /_/ / /_/ /  __/ /                      \r\n" + //
                "/________,_/_.___/\\___/_/            __         \r\n" + //
                "   /   |  ____  ________  ____  ____/ /__  _____\r\n" + //
                "  / /| | / __ \\/ ___/ _ \\/ __ \\/ __  / _ \\/ ___/\r\n" + //
                " / ___ |/ /_/ / /  /  __/ / / / /_/ /  __/ /    \r\n" + //
                "/_/  |_/ .___/_/   \\___/_/ /_/\\__,_/\\___/_/     \r\n" + //
                "    ____/                                       \r\n" + //
                "   / __ \\___  ____  _________ ______            \r\n" + //
                "  / /_/ / _ \\/ __ \\/ ___/ __ `/ ___/            \r\n" + //
                " / ____/  __/ / / (__  ) /_/ / /                \r\n" + //
                "/_/ _______/_/ /_/____/\\__,/\\//                 \r\n" + //
                "   / ____/___  ________  _//\\/ ____ ______      \r\n" + //
                "  / __/ / __ \\/ ___/ _ \\/ __ \\/ __ `/ ___/      \r\n" + //
                " / /___/ / / (__  )  __/ / / / /_/ / /          \r\n" + //
                "/_____/_/ /_/____/\\___/_/ /_/\\__,_/_/           \r\n" + //
                "                                                \r\n" + //
                "");
        System.out.println(
                "..............................................................................................");
        System.out.println("Presione:");
        System.out.println("* 1.Ver catalogo\n" +
                "* 2.Crear un libro\n" +
                "* 0.Salir");
        eleccion = sc.nextInt();

    }

    public static void VerCatalogo() {

        System.out.println("Ingrese \n" +
                "* 1.Mostrar todo el catalogo\n" +
                "* 2.Mostrar los temas disponibles\n" +
                "* 3.Mostrar los libros reservados\n");
        eleccion = sc.nextInt();

        switch (eleccion) {

            case 1:
                Archvos.MostrarArchivos(Raiz);

                break;
            case 2:
                Temario();
                break;
            case 3:
                MostrarReservados(reservado);
                break;

        }

    }

    public static void Temario() {

        System.out.println("Ingrese\n" +
                "* 1.Ver los libros de desarrollo personal\n" +
                "* 2.Ver los libros de tematica historias\n" +
                "* 3.Ver los libros de tematica matematicas\n" +
                "* 4.Ver los libros de tematica misticos\n" +
                "* 5.Ver los libros de otras tematicas");

        eleccion = sc.nextInt();

        switch (eleccion) {

            case 1:
                MostrarArchivos(desarrolloPersonal);
                break;

            case 2:
                MostrarArchivos(historias);
                break;

            case 3:
                MostrarArchivos(matematicas);
                break;

            case 4:
                MostrarArchivos(misticos);
                break;

            case 5:
                MostrarArchivos(otros);
                break;

        }

    }

    public static void MostrarDisponibles() {
        MostrarArchivos(Tematicas);
    }

    public static void LeerLibro(String RutaGeneral) {

        System.out.println("Ingrese el nombre del libro que desee leer");
        nombreArchivo = eleccionLeer.nextLine();

        File aaa = new File(RutaGeneral + "\\" + nombreArchivo + ".txt");

        try {
            FileReader lector = new FileReader(aaa);
            int caracter;
            while ((caracter = lector.read()) != -1) {
                System.out.print((char) caracter);

            }
        } catch (IOException e) {
            System.out.println("El libro no se ha podido leer");
        }

    }

    public static void MostrarArchivos(File Ruta) {

        RutaGeneral = Ruta.getAbsolutePath();
        if (Ruta.exists()) {
            for (File ArchDire : Ruta.listFiles()) {

                if (ArchDire.isFile()) {

                    biblioteca.SacarTXT(ArchDire.getName());
                }

                else if (ArchDire.isDirectory()) {
                    System.out.println(ArchDire.getName() + ": ");
                    MostrarArchivos(ArchDire);
                }
            }
        }

        if (Ruta == otros) {
            System.out.println("Presione 1 para leer el libro");
            System.out.println("Presione 2 para retirar el libro");
            eleccion = sc.nextInt();
            switch (eleccion) {
                case 1:
                    LeerJson();
                    break;
                case 2:
                    RetirarLibroJson(RutaGeneral);
            }
        } else {
            System.out.println("Presione 1 para leer el libro");
            System.out.println("Presione 2 para retirar el libro");
            eleccion = sc.nextInt();
            switch (eleccion) {
                case 1:
                    LeerLibro(RutaGeneral);
                    break;
                case 2:
                    RetirarLibro(RutaGeneral);
                    break;
            }
        }
    }

    public static void RetirarLibro(String RutaGeneral) {

        System.out.println("Ingrese el nombre del libro que desee reservar");
        eleccionArchivo = eleccionAr.nextLine();
        Path origen = Paths.get(RutaGeneral + "\\" + eleccionArchivo + ".txt");
        Path destino = Paths.get(reservado.getAbsolutePath());
        try {

            Path mover = Files.move(origen, destino.resolve(origen.getFileName()), StandardCopyOption.REPLACE_EXISTING);
            System.out.println("Se retiro el libro: " + "\"" + eleccionArchivo + "\"" + " con exito");

        } catch (Exception e) {

            System.out.println(e);

        }

    }

    public static void MostrarReservados(File reservados) {
        for (File cadena : reservados.listFiles()) {

            Archvos.SacarTXT(cadena.getName());
        }

    }

    public static void AgregarLibro() throws IOException {

        System.out.print("Ingrese el nombre del libro: ");
        nombreLibro = eleccionAr.nextLine();
        System.out.print("Ingrese el autor del libro: ");
        autorLibro = eleccionAr.nextLine();
        System.out.print("Ingrese una descripcion del libro: ");
        descripcionLibro = eleccionAr.nextLine();
        Archvos.CrearLibro(nombreLibro, autorLibro, descripcionLibro);

    }

    public static void LeerJson() {
        System.out.println("Ingrese el nombre del libro");
        nombreArchivo = eleccionLeer.nextLine();
        String RutaArchivo = RutaGeneral + "\\" + nombreArchivo + ".json";

        JSONParser jsonParser = new JSONParser();
        try (FileReader fileReader = new FileReader(RutaArchivo)) {

            Object objetoJSON = jsonParser.parse(fileReader);

            String jsonFormateado = objetoJSON.toString();

            System.out.println(jsonFormateado);
        }

        catch (FileNotFoundException e) {
            System.err.println("El archivo no existe, vuelva a intentar");
        } catch (IOException e) {

            System.err.println("No se pudo");
        } catch (org.json.simple.parser.ParseException e) {

            System.err.println("Hubo un problema, intente nuevamente");
        }

    }

    public static void RetirarLibroJson(String RutaGeneral) {

        System.out.println("Ingrese el nombre del libro que desee reservar");
        eleccionArchivo = eleccionAr.nextLine();
        Path origen = Paths.get(RutaGeneral + "\\" + eleccionArchivo + ".json");
        Path destino = Paths.get(reservado.getAbsolutePath());
        try {

            Path mover = Files.move(origen, destino.resolve(origen.getFileName()), StandardCopyOption.REPLACE_EXISTING);
            System.out.println("Se reservo el libro: " + "\"" + eleccionArchivo + "\"" + " con exito");

        } catch (Exception e) {

            System.out.println(e);

        }

    }
}
